package br.com.fiap.bss.repository;

import br.com.fiap.bss.model.LogSistema;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogSistemaRepository extends JpaRepository<LogSistema, Long> {
}