package br.com.fiap.bss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BssApplicationTests {

	@Test
	void contextLoads() {
	}

}
